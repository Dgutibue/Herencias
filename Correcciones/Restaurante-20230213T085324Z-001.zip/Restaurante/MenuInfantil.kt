package Restaurante

class MenuInfantil: Menu() {
    override var cartaBebidas = mapOf<String, Float>("Refresco" to 1f, "Zumo" to 1.5f, "Otros" to 2f)
    var regalo: String = ""
        get() {
            return field
        }
        set(value) {
            field = value
            val contenido = "muñeca, soldado"
            if(field !in contenido){
                var respuesta = ""
                do{
                    println("Solo puede eligir entre la mañuca o el soldado")
                    respuesta = readln()
                    field = respuesta
                }while (field !in contenido)
            }
        }
    override fun importe():Float{
        val total = 12f * 1.21f
        return total
    }
    override fun mostrarCarta(){
        super.mostrarCarta()
        println("Hay un regalo a elegir con este menu")
    }

}




fun main(args: Array<String>){
    println("¿Cuántos comensales van a ser? (Máximo 12)")
    var comensales = 0
    var mimenu = Menu()
   // var infantil = MenuInfantil()
    var turno = 0
    var total = 0f
    do{
        comensales = readln().toInt()
        if(comensales > 12){
            println("Error no se puede superar el aforo")
        }
    }while(comensales > 12)
    println("Menu normal")
    println("${mimenu.mostrarCarta()}")
    println()
    println("Menu infantil")
    println()
    println("${mimenu.mostrarCarta()}")

     do{
        println("¿Qué tipo de menu va a tomar?\n1.Normal\n2.Infantil")
        var menu = readln().toInt()
        if(menu == 1){
            mimenu = Menu()
            println("¿Qué plato va a tomar?")
            var plato = readln()
            mimenu.principal = plato
            println("¿Qué bebida va a tomar?")
            var bebida = readln().toInt()
            mimenu.bebida = bebida
            println("¿Que postre va a tomar?")
            var postre = readln().toInt()
            mimenu.postre = postre
        }else {
            mimenu = MenuInfantil()
            println("¿Qué plato va a tomar?")
            var plato = readln()
            mimenu.principal = plato
            println("¿Qué bebida va a tomar?")
            var bebida = readln().toInt()
            mimenu.bebida = bebida
            println("¿Que postre va a tomar?")
            var postre = readln().toInt()
            mimenu.postre = postre
            println("¿Qué regalo desea? (muñeca/soldado)")
            var regalo = readln()
            mimenu.regalo = regalo

        }
         if(total > 140f){
             println("No tienes tanto dinero en la tarjeta")
             break
         }
         total = mimenu.importe()
         turno ++

         mimenu.mostrar()
     }while(turno < comensales)
     println("$total€")
}
